﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Class_W06_y
{
    public partial class Form1 : Form
    {
        DataTable dtteam;
        public List<string> teamlist = new List<string>();
        public List<string> teamlist2 = new List<string>();
        Form2 form;
        public Form1()
        {
            InitializeComponent();
            tb_team1.KeyPress += tb_team1_KeyPress;
            tb_team2.KeyPress += tb_team2_KeyPress; 
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            dtteam = new DataTable();
            dtteam.Columns.Add("Date");
            dtteam.Columns.Add("Home Team Name");
            dtteam.Columns.Add("Home Score");
            dtteam.Columns.Add("Away Score");
            dtteam.Columns.Add("Away Team Name");

            dg_team.DataSource = dtteam;


            teamlist.Add("Boston Celtics");
            teamlist.Add("New York Knicks");
            teamlist.Add("Philadelphia 76ers");
            teamlist.Add("Toronto Raptors");
            teamlist.Add("Chicago Bulls");
            teamlist.Add("Cleveland Cavalier");
            teamlist.Add("Detroit Pistons");
            teamlist.Add("Indiana Pacers");
            teamlist.Add("Milwauke Bucks");

            teamlist2.Add("Boston Celtics");
            teamlist2.Add("New York Knicks");
            teamlist2.Add("Philadelphia 76ers");
            teamlist2.Add("Toronto Raptors");
            teamlist2.Add("Chicago Bulls");
            teamlist2.Add("Cleveland Cavalier");
            teamlist2.Add("Detroit Pistons");
            teamlist2.Add("Indiana Pacers");
            teamlist2.Add("Milwauke Bucks");



            foreach (var i in  teamlist)
            {
                cb_team1.Items.Add(i);
            }

            foreach (var j in teamlist2)
            {
                cb_team2.Items.Add(j);
            }



            cb_team1.SelectedIndex = -1;
            cb_team2.SelectedIndex = -1;


        }
        private void tb_team1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        private void tb_team2_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void cb_team1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_team1.SelectedIndex >= -1)
            {
                string selectedTeam = (string)cb_team1.SelectedItem;
                if (cb_team2.Items.Contains(selectedTeam))
                {
                    cb_team2.Items.Clear();
                    foreach (var j in teamlist2)
                    {
                        cb_team2.Items.Add(j);
                    }
                    cb_team2.Items.Remove(selectedTeam);
                    
                }

                    
                
            }
        }

        private void cb_team2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cb_team2.SelectedIndex >= -1 )
            {
                string selectedTeam2 = (string)cb_team2.SelectedItem;
                if (cb_team1.Items.Contains(selectedTeam2))
                {
                    cb_team1.Items.Clear();
                    foreach (var i in teamlist)
                    {
                        cb_team1.Items.Add(i);
                    }
                    cb_team1.Items.Remove(selectedTeam2); 
                }
                
            }
        }

        private void btn_addmatch_Click(object sender, EventArgs e)
        {
            bool exit = true;

            if (exit == true)
            {
                string date = dateTimePicker1.Value.ToString();
                dtteam.Rows.Add(date, cb_team1.Text, tb_team1.Text, tb_team2.Text, cb_team2.SelectedItem);
            }

            
        }

        private void btn_addteam_Click(object sender, EventArgs e)
        {
            form = new Form2(this);
            form.Show();

        }

        public void addteam(string team)
        {
            if (cb_team1.Items.Contains(team) && cb_team2.Items.Contains(team))
            {
                MessageBox.Show("ERRROR");
            }

            else
            {
                teamlist.Add(team);
                cb_team1.Items.Add(team);
                cb_team2.Items.Add(team);
                teamlist2.Add(team);
            }
            
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            DataGridViewRow dgvr = dg_team.CurrentRow;
            dg_team.Rows.Remove(dgvr);
        }
    }
}
