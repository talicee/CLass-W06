﻿namespace Class_W06_y
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dg_team = new System.Windows.Forms.DataGridView();
            this.btn_delete = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.cb_team1 = new System.Windows.Forms.ComboBox();
            this.cb_team2 = new System.Windows.Forms.ComboBox();
            this.lb_vs = new System.Windows.Forms.Label();
            this.tb_team1 = new System.Windows.Forms.TextBox();
            this.tb_team2 = new System.Windows.Forms.TextBox();
            this.btn_addmatch = new System.Windows.Forms.Button();
            this.btn_addteam = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dg_team)).BeginInit();
            this.SuspendLayout();
            // 
            // dg_team
            // 
            this.dg_team.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_team.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dg_team.Location = new System.Drawing.Point(57, 37);
            this.dg_team.Name = "dg_team";
            this.dg_team.RowHeadersWidth = 82;
            this.dg_team.RowTemplate.Height = 33;
            this.dg_team.Size = new System.Drawing.Size(1221, 501);
            this.dg_team.TabIndex = 0;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(65, 568);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(134, 44);
            this.btn_delete.TabIndex = 2;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(460, 573);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(432, 31);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // cb_team1
            // 
            this.cb_team1.FormattingEnabled = true;
            this.cb_team1.Location = new System.Drawing.Point(460, 627);
            this.cb_team1.Name = "cb_team1";
            this.cb_team1.Size = new System.Drawing.Size(173, 33);
            this.cb_team1.TabIndex = 4;
            this.cb_team1.SelectedIndexChanged += new System.EventHandler(this.cb_team1_SelectedIndexChanged);
            // 
            // cb_team2
            // 
            this.cb_team2.FormattingEnabled = true;
            this.cb_team2.Location = new System.Drawing.Point(719, 627);
            this.cb_team2.Name = "cb_team2";
            this.cb_team2.Size = new System.Drawing.Size(173, 33);
            this.cb_team2.TabIndex = 5;
            this.cb_team2.SelectedIndexChanged += new System.EventHandler(this.cb_team2_SelectedIndexChanged);
            // 
            // lb_vs
            // 
            this.lb_vs.AutoSize = true;
            this.lb_vs.Location = new System.Drawing.Point(662, 627);
            this.lb_vs.Name = "lb_vs";
            this.lb_vs.Size = new System.Drawing.Size(34, 25);
            this.lb_vs.TabIndex = 6;
            this.lb_vs.Text = "vs";
            // 
            // tb_team1
            // 
            this.tb_team1.Location = new System.Drawing.Point(460, 694);
            this.tb_team1.Name = "tb_team1";
            this.tb_team1.Size = new System.Drawing.Size(173, 31);
            this.tb_team1.TabIndex = 7;
            // 
            // tb_team2
            // 
            this.tb_team2.Location = new System.Drawing.Point(719, 694);
            this.tb_team2.Name = "tb_team2";
            this.tb_team2.Size = new System.Drawing.Size(173, 31);
            this.tb_team2.TabIndex = 8;
            // 
            // btn_addmatch
            // 
            this.btn_addmatch.Location = new System.Drawing.Point(453, 747);
            this.btn_addmatch.Name = "btn_addmatch";
            this.btn_addmatch.Size = new System.Drawing.Size(180, 49);
            this.btn_addmatch.TabIndex = 9;
            this.btn_addmatch.Text = "Add Match";
            this.btn_addmatch.UseVisualStyleBackColor = true;
            this.btn_addmatch.Click += new System.EventHandler(this.btn_addmatch_Click);
            // 
            // btn_addteam
            // 
            this.btn_addteam.Location = new System.Drawing.Point(736, 747);
            this.btn_addteam.Name = "btn_addteam";
            this.btn_addteam.Size = new System.Drawing.Size(133, 49);
            this.btn_addteam.TabIndex = 10;
            this.btn_addteam.Text = "Add Team";
            this.btn_addteam.UseVisualStyleBackColor = true;
            this.btn_addteam.Click += new System.EventHandler(this.btn_addteam_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1332, 850);
            this.Controls.Add(this.btn_addteam);
            this.Controls.Add(this.btn_addmatch);
            this.Controls.Add(this.tb_team2);
            this.Controls.Add(this.tb_team1);
            this.Controls.Add(this.lb_vs);
            this.Controls.Add(this.cb_team2);
            this.Controls.Add(this.cb_team1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.dg_team);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dg_team)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dg_team;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox cb_team1;
        private System.Windows.Forms.ComboBox cb_team2;
        private System.Windows.Forms.Label lb_vs;
        private System.Windows.Forms.TextBox tb_team1;
        private System.Windows.Forms.TextBox tb_team2;
        private System.Windows.Forms.Button btn_addmatch;
        private System.Windows.Forms.Button btn_addteam;
    }
}

